<?php
define('DB_USER', "root"); // db user
define('DB_PASSWORD', ""); // db password (mention your db password here)
define('DB_NAME', "gp"); // database name
define('DB_HOST', "localhost"); // db server
?>